# Λεξούλα — Οδηγός Deploy στο Play Store

## Βήμα 1: Deploy το PWA

Ανέβασε τα αρχεία σε hosting με HTTPS (απαραίτητο για PWA):

### Επιλογές Hosting (δωρεάν):
- **Netlify**: Σύρε τον φάκελο στο netlify.com/drop → άμεσο deploy
- **Vercel**: `npx vercel --prod` στον φάκελο
- **GitHub Pages**: Push σε repo → Settings → Pages → Deploy

```
greek-wordle/
├── index.html      ← Το παιχνίδι
├── manifest.json   ← PWA manifest
├── sw.js           ← Service Worker (offline support)
└── icons/
    ├── icon-192.png
    └── icon-512.png
```

Αφού ανέβει, το URL θα είναι π.χ.: `https://lexoula.netlify.app`

---

## Βήμα 2: Δημιουργία εικονιδίων

Χρειάζεσαι:
- **512×512 PNG** → Play Store listing icon
- **192×192 PNG** → PWA launcher icon (ήδη έτοιμο)

Βελτίωσε τα εικονίδια με Figma, Canva ή Adobe Express.

---

## Βήμα 3: Δημιουργία TWA (Trusted Web Activity)

Η TWA είναι ο τρόπος που ένα PWA μπαίνει στο Play Store ως native app.

### Εργαλεία (επίλεξε ένα):

#### Α) Bubblewrap CLI (Google's official tool)
```bash
npm install -g @bubblewrap/cli
mkdir lexoula-twa && cd lexoula-twa
bubblewrap init --manifest https://lexoula.netlify.app/manifest.json
bubblewrap build
```

#### Β) PWABuilder (web UI, πιο εύκολο)
1. Πήγαινε στο **pwabuilder.com**
2. Βάλε το URL του PWA σου
3. Κάνε κλικ **"Package for Stores"**
4. Επίλεξε **"Google Play"**
5. Κατέβασε το `.apk` / `.aab`

---

## Βήμα 4: Ρύθμιση Digital Asset Links

Αυτό συνδέει το domain σου με το app (απαραίτητο για TWA).

1. Δημιούργησε keystore:
```bash
keytool -genkey -v -keystore lexoula.keystore -alias lexoula -keyalg RSA -keysize 2048 -validity 10000
```

2. Πάρε το SHA-256 fingerprint:
```bash
keytool -list -v -keystore lexoula.keystore -alias lexoula
```

3. Δημιούργησε το αρχείο `.well-known/assetlinks.json` στο root του domain:
```json
[{
  "relation": ["delegate_permission/common.handle_all_urls"],
  "target": {
    "namespace": "android_app",
    "package_name": "gr.lexoula.app",
    "sha256_cert_fingerprints": ["AA:BB:CC:...το fingerprint σου..."]
  }
}]
```

---

## Βήμα 5: Play Console

1. Πήγαινε στο **play.google.com/console**
2. Δημιούργησε νέα εφαρμογή:
   - Κατηγορία: **Games → Word**
   - Γλώσσα: **Ελληνική**
3. Ανέβασε το `.aab` αρχείο
4. Συμπλήρωσε:
   - **Τίτλος**: Λεξούλα - Ελληνικό Wordle
   - **Σύντομη περιγραφή**: Βρες τη ελληνική λέξη σε 6 προσπάθειες!
   - **Περιγραφή**: (βλέπε παρακάτω)
   - Screenshots: τουλάχιστον 2 για κινητά (1080×1920)
   - Feature graphic: 1024×500 PNG

### Κείμενο περιγραφής:
```
🇬🇷 Το Wordle στα Ελληνικά!

Κάθε μέρα μια νέα λέξη 5 γραμμάτων. Έχεις 6 προσπάθειες να τη βρεις.

🟩 Πράσινο = σωστό γράμμα, σωστή θέση
🟨 Κίτρινο = σωστό γράμμα, λάθος θέση  
⬛ Γκρι = το γράμμα δεν υπάρχει

✨ Χαρακτηριστικά:
• Νέα λέξη κάθε ημέρα
• Στατιστικά & σερί νικών
• Μοιράσου τα αποτελέσματα
• Παίζει offline
• Δωρεάν, χωρίς διαφημίσεις
```

---

## Βήμα 6: Rating & Release

- **Content Rating**: Συμπλήρωσε το ερωτηματολόγιο → θα πάρεις ESRB/PEGI "Everyone"
- **Τιμολόγηση**: Δωρεάν
- **Χώρες**: Επίλεξε "All countries" ή εστίασε σε Ελλάδα/Κύπρο
- Κάνε submit → review 3-7 ημέρες

---

## Χρήσιμοι Σύνδεσμοι

- PWABuilder: https://pwabuilder.com
- Bubblewrap: https://github.com/GoogleChromeLabs/bubblewrap
- Play Console: https://play.google.com/console
- Digital Asset Links: https://developers.google.com/digital-asset-links
- TWA docs: https://developer.chrome.com/docs/android/trusted-web-activity

---

## Κόστος

| Τι | Κόστος |
|---|---|
| Google Play Developer Account | $25 (εφάπαξ) |
| Hosting (Netlify/Vercel free tier) | €0 |
| Το app | €0 |

**Σύνολο: $25** για να μπεις στο Play Store.
